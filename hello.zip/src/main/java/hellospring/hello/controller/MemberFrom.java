package hellospring.hello.controller;

public class MemberFrom {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    // 웹 등록화면에서 데이터를 전달받을 폼객제 - 회원등록 컨트롤러



}
